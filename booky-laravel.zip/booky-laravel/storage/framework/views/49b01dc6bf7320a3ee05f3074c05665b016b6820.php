<?php $__env->startSection('custom-style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>


<div class="container1" style="background-image: url('images/bg-01.jpg');">
  <div class="container2 fondo paral altura-minima">
    <div class="wrap-container container altura-minima">
        <div class="row p-4">
        <h2 class="form-title col-12">Detalle de este libro</h2>
        <div class="row col-12 mx-auto">
          <div class="col-lg-8">
            <div class="card my-4">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($book->title->name); ?></h5>
                <p class="card-text"><?php echo e($book->review); ?></p>
                <ul class="list-group list-group-flush">

                  <?php if($usuarioLog->id!=$book->user_id): ?>
                 <li class="list-group-item">Compartido por:<a style="color:#18867a; font-weight:bolder"  href="/normalProfile/<?php echo e($book->user_id); ?>"> <?php echo e($book->user->name); ?> </a> </li>
                 <?php else: ?>
                  <li class="list-group-item">Compartido por:<a style="color:#18867a; font-weight:bolder"  href="/profile"> <?php echo e($book->user->name); ?> </a> </li>
                 <?php endif; ?>

            <?php if(Auth::User()->id !== $book->user_id): ?>
                <?php if($book->state_id == 1): ?>
                <li class="list-group-item"> ¡Disponible! <a href="/solicitar/<?php echo e($book->id); ?>" class="btn btn-success m-2">Solicitar</a></li>
                <?php elseif($book->state_id == 2): ?>
                <li class="list-group-item"><a href="#" class="btn btn-success m-2">Solicitado</a></li>
                <?php elseif($book->state_id == 3): ?>
                <li class="list-group-item3"><a href="#" class="btn btn-success m-2">Prestado</a></li>
                <?php endif; ?>
            <?php else: ?>
                <?php if($book->state_id == 1): ?>
                <li class="list-group-item">Disponible para prestar</li>
                <?php elseif($book->state_id == 2): ?>
                <li class="list-group-item">¡Tu libro fue solicitado! <a href="/confirmar/<?php echo e($book->id); ?>" class="btn btn-success m-2">Confirmar préstamo</a></li>
                <?php elseif($book->state_id == 3): ?>
                <li class="list-group-item"><a href="/devolver/<?php echo e($book->id); ?>" class="btn btn-success m-2">Confirmar devolución</a></li>
                <?php endif; ?>
            <?php endif; ?>
               </ul>
              </div>
            </div>
          </div>

        <div class="container-image col-lg-4">
          <div class="container-image-in text-center">
              <img class="mt-4 img-fluid"src="/storage/<?php echo e($book->image); ?>" alt="IMG">
          </div>
        </div>

    </div>

    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>