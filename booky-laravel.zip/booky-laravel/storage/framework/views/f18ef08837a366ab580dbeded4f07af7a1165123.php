;

<?php $__env->startSection('main'); ?>
<div class="fondo paral">
<div class="container">
<div class="row p-4">
      <h2 class="col-12 form-title pb-4">Encontramos estos libros</h2>
      <?php $__empty_1 = true; $__currentLoopData = $librosFinales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card col-lg-8 p-4 my-3 mx-auto">
          <div class="card-body row">
            <div class="col-lg-3 miniatura">
              <img src="/storage/<?php echo e($libro->image); ?>" alt="" class="img-thumbnail">
            </div>
            <ul class="col-lg-9">
              <h5><?php echo e($libro->title->name); ?></h5>
              <li class="list-group-item">  Autor: <?php echo e($libro->author->name); ?> </li>
              <li class="list-group-item">Estado de este ejemplar: <?php echo e($libro->state->name); ?></li>
              <a href="/bookPost/<?php echo e($libro->id); ?>" class="btn btn-success mt-3">Ver más</a>
            </ul>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="altura minima">
            No hay libros disponibles
          </div>
      <?php endif; ?>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>