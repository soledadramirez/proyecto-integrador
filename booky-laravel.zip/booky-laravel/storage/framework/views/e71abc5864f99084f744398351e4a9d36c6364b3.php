<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="col-sm-offset-2 col-sm-8">


            <div class="panel panel-default">
                <div class="panel-heading" style="margin-top:20%">
                    Todos los usuarios:
                </div>

                <div class="panel-body">
                    <table class="table table-striped task-table">
                        <thead>
                            <th>User</th>
                            <th> </th>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="table-text"><div><?php echo e($user->name); ?></div></td>
                                    <?php if(Auth::User()->isFollowing($user->id)): ?>
    <td>
        <form action="<?php echo e(url('unfollow/' . $user->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>


            <button type="submit" id="delete-follow-<?php echo e($user->target_id); ?>" class="btn btn-danger">
            <i class="fa fa-btn fa-trash"></i>Unfollow
            </button>
        </form>
    </td>
<?php else: ?>
    <td>
        <form action="<?php echo e(url('follow/' . $user->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>


            <button type="submit" id="follow-user-<?php echo e($user->id); ?>" class="btn btn-success">
            <i class="fa fa-btn fa-user"></i>Follow
            </button>
        </form>
    </td>
<?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>