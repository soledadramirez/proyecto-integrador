<?php $__env->startSection('main'); ?>
  <div class="fondo paral">
  <nav class="container navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand a-blanco" href="/home"><h1>Booky</h1> </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">

      <ul class="navbar-nav mr-auto">

        <li class="nav-item">
          <a class="nav-link a-blanco" href="#">Nosotros</a>
        </li>
        <li class="nav-item">
          <a class="nav-link a-blanco" href="#">FAQ</a>
        </li>
      </ul>

    </div>
  </nav>
<div class="fondoProfile">
  <div class="container header-profile">
  <div class="row profileImage jumbotron">
  <div class="col-sm-6">
    <div class="circle">
      <img src="/images/fotoPerfil.jpg" alt="">
    </div>
      <button type="button" class="btn btn-success agregImage"><i class="fas fa-pen-square"></i></button>
  </div>
  <div class="col-sm-6 profile-info">
    <div class="user-info">
    <div class="row">
      <h4 class="col-sm-7 user-data"><?php echo e(Auth::user()->name); ?></h4>
      <button class="col-sm-5 btn btn-link edit text-left " type="submit" name="button">Editar perfil</button>
    </div>
     <div class="row user-data user-follow">
      <h4 class="col-sm-5"> 0 seguidores</h4>
      <h4 class="col-sm-5 ">0 seguidos  </h4>
    </div>
      </div>
    <div class="row user-data book-button">
    <button type="submit" name="button" class="col-sm-5 btn btn-success"><a href="/agregarLibros">Cargar libro</a></button>
    
   </div>
  </div>
  </div>
    
      <div class="container profile">
      <div class="row py-2">
        <div class=""> 
      
      <div class="">
        <div class="librosInfo row">
          <div class="librosAPrestar col-12 row w-100 mx-auto">

            <h1 class="text-center col-sm-12">Libros para prestar</h1>

          
                

            <?php $__empty_1 = true; $__currentLoopData = $myBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="book-image col-md-6 col-lg-3">
                <a href="/bookPost/<?php echo e($book->id); ?>">
                 <img class="rounded mx-auto d-block" src="/storage/<?php echo e($book->image); ?>" alt="">
                </a>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <p>Por el momento no ha libros cargados</p>
            <?php endif; ?>

          </div>
          <div class="librosLeyendo col-12 row w-100 mx-auto">
            <h1 class="text-center col-sm-12">Son de mi interés</h1>
            <div class="book-image col-md-6 col-lg-3 rounded mx-auto d-block">
              <img class="rounded mx-auto d-block" src="/images/garcia-marquez.jpg" alt="">
            </div>
            <div class="book-image col-md-6 col-lg-3">
              <img class="rounded mx-auto d-block" src="/images/garcia-marquez.jpg" alt="">
            </div>
            <div class="book-image col-md-6 col-lg-3">
              <img class="rounded mx-auto d-block" src="/images/garcia-marquez.jpg" alt="">
            </div>
            <div class="book-image col-md-6 col-lg-3">
              <img class="rounded mx-auto d-block" src="/images/garcia-marquez.jpg" alt="">
            </div>
          </div>
          <div class="librosPrestados col-12 row w-100 mx-auto">
            <h1 class="text-center col-sm-12">Libros prestados</h1>
            <div class="book-image col-md-6 col-lg-3">
              <img class="rounded mx-auto d-block" src="/images/garcia-marquez.jpg" alt="">
            </div>
            <div class="book-image col-md-6 col-lg-3">
              <img class="rounded mx-auto d-block" src="/images/garcia-marquez.jpg" alt="">
            </div>
            <div class="book-image col-md-6 col-lg-3">
              <img class="rounded mx-auto d-block" src="/images/garcia-marquez.jpg" alt="">
            </div>
            <div class="book-image col-md-6 col-lg-3">
              <img class="rounded mx-auto d-block" src="/images/garcia-marquez.jpg" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>




        </div>

  </div>

  </div>
  </div>
</div>
</div>
<footer class="col-lg-12 footer-home">
  <ul class="navbar-nav mr-auto">
    <li class="nav-item active">
      <a class="nav-link" href="#">Home<span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Nosotros</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">FAQ</a>
    </li>
  </ul>
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>