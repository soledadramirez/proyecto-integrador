<?php $__env->startSection('main'); ?>

<link rel="stylesheet" type="text/css" href="css/agregarLibros.css">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="/home"><h1>Booky</h1> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/home">Home<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Nosotros</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">FAQ</a>
      </li>
    </ul>
    <ul class="nav navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="/register"><span class="fas fa-user"></span> Sign Up</a>
      </li>
      <?php if (isset($_SESSION["email"])): ?>
      <li class="nav-item">
        <a class="nav-link" href="/logout"><span class="fas fa-sign-in-alt"></span> Logout</a>
        <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="/login"><span class="fas fa-sign-in-alt"></span> Login</a>
      <?php endif ?>
      </li>
    </ul>
  </div>
</nav>

<ul class="errores" style:"color:red">
  <?php foreach ($errors->all() as $error): ?>
    <li>
      <?= $error?>
    </li>
  <?php endforeach; ?>
</ul>
<div class="container1" style="background-image: url('images/bg-01.jpg');">
  <div class="container2">
    <div class="wrap-container">
      <div class="container-image">
        <div class="container-image-in">

          <form action="/agregarLibros" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>


            <img src="images/agregarPortada.png" alt="IMG">
          </div>
          <div class="container-form-btn">
            <input type="file" onchange="previewFile()" name="book_cover"><br>
           <img src="" height="200" alt="Agregar portada">
          </div>

      </div>


      <div class="container-form">

        <span class="form-title">
          Datos del libro
        </span>

        <div class="wrap-input">
          <input class="input100" type="text" name="name" placeholder="Nombre del libro" value="<?php echo e(old("name")); ?>">
          <span class="focus-input100"></span>
          <span class="symbol-input100">
            <i class="fas fa-book"></i>
          </span>
          <small><?php echo e($errors->first('name')); ?></small>
        </div>

        <div class="wrap-input">
          <input class="input100" type="text" name="author" placeholder="Nombre del autor" value="<?php echo e(old("author")); ?>">
          <span class="focus-input100"></span>
          <span class="symbol-input100">
            <i class="fas fa-feather"></i>
          </span>
          <small><?php echo e($errors->first('author')); ?></small>

        </div>

        <div class="wrap-input">

          <select name="book_action" class="form-control select100" id="exampleFormControlSelect1">
          <option>Disponible para:</option>
          <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="wrap-input validate-input">
          <textarea class="input100" name="description" placeholder="Agrega una reseña de este libro" value="<?php echo e(old("description")); ?>"></textarea>
          <span class="focus-input100"></span>
          <small><?php echo e($errors->first('description')); ?></small>

        </div>

        <div class="container-form-btn">
          <button type="submit" class="form-btn">
            Cargar al perfil
          </button>
        </div>
      </div>
      </form>
    </div>
  </div>
</div>

<script src="js/addImg.js">

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>