<?php $__env->startSection('main'); ?>
  
  <div class="container">
    <div class="row cont-form">
        <div class="col-sm-12 panel-cont">
            <div class="panel panel-defaut offset-lg-6">
                <div class="panel-body">
                    <form class="form-horizontal form-login col-md-12" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                          <h2>Ingresa</h2>
                        <div class="datos form-group row<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-form-label d-none d-md-block"><i class="fas fa-user"></i></label>

                            <div class="col-md-11 col-sm-12 pl-0 pr-0">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="ingresa tu email" autofocus>

                                <?php if($errors->has('email')): ?>
                                  <p>
                                    <span class="help-block errores">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                  </p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="datos form-group row<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-form-label d-none d-md-block"><i class="fas fa-lock"></i></label>

                            <div class="col-md-11 col-sm-12 pl-0 pr-0">
                                <input id="password" type="password" class="form-control " name="password" placeholder="ingresa tu contraseña">

                                <?php if($errors->has('password')): ?>
                                  <p class="">
                                    <span class="help-block errores">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4 mx-auto">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Recordarme
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group recover">
                            <div class="col-md-8 mx-auto">
                                <button type="submit" class="btn btn-primary btn-login w-75">
                                    Ingresa
                                </button>

                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    ¿Olvidaste tu contraseña?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>