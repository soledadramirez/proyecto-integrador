<ul>
<?php $__currentLoopData = $userBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<li> <?php echo e($userbook->title->name); ?></li>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
