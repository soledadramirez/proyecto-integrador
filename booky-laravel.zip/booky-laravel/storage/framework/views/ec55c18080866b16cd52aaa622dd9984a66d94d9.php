<?php $__env->startSection('custom-style'); ?>
  <link rel="stylesheet" href="/css/follow.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
  <div class="fondo paral">
 <div class="fondoProfile">
  <div class="container header-profile">
  <div class="row profileImage jumbotron">
  <div class="col-sm-6">
    <div class="circle">
      <img src="/images/fotoPerfil.jpg" alt="">
    </div>
      <button type="button" class="btn btn-success agregImage"><i class="fas fa-pen-square"></i></button>
  </div>
  <div class="col-sm-6 profile-info">
    <div class="user-info">
    <div class="row">
      <h4 class="userName"><?php echo e($user->name); ?></h4>
    </div>
     <div class="row user-data user-follow">

       <button id="myBtn" style="border-radius:5px;color:#18867a;background-color:white"><span class="col-sm-5 p-2"> <?php echo e(count($follow)); ?> seguidores</span></button>


   <div id="myModal" class="modal">


     <div class="modal-content">
       <h1>lista de seguidores <span style"display:inline-block" class="close">&times;</span></h1>

       <?php $__empty_1 = true; $__currentLoopData = $follow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
       <?php if($usuarioLog->id!=$follower->user->id): ?>
       <p> <a style="color:black; font-weight:bolder"  href="/normalProfile/<?php echo e($follower->user->id); ?>"><?php echo e($follower->user->name); ?></a></p>
       <?php else: ?>
       <p> <a style="color:black; font-weight:bolder"  href="/profile"><?php echo e($follower->user->name); ?></a></p>
      <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
       <p> No tiene ningún seguidor</p>
       <?php endif; ?>
     </div>

   </div>

   <button id="myBtn1" style="border-radius:5px;color:#18867a;background-color:white;margin-left:5%">      <span class="col-sm-5 p-2"><?php echo e(count($following)); ?> seguidos  </span></button>


<div id="myModal1" class="modal1">


  <div class="modal-content1">
    <span class="close1">&times;</span>
    <h1>lista de seguidos</h1>

    <?php $__empty_1 = true; $__currentLoopData = $following; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $following_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if($usuarioLog->id!=$following_user->user->id): ?>
    <p> <a style="color:black; font-weight:bolder"  href="/normalProfile/<?php echo e($following_user->user->id); ?>"><?php echo e($following_user->user->name); ?></a></p>
    <?php else: ?>
    <p> <a style="color:black; font-weight:bolder"  href="/profile"><?php echo e($following_user->user->name); ?></a></p>
   <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p> Este usuario no sigue a nadie</p>
    <?php endif; ?>
  </div>

</div>



    </div>
    <?php if(Auth::User()->isFollowing($user->id)): ?>

<form action="<?php echo e(url('unfollow/' . $user->id)); ?>" method="POST" style="text-align:left;margin-top:5%">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>


<button type="submit" id="delete-follow-<?php echo e($user->target_id); ?>" class="btn btn-danger">
<i class="fa fa-btn fa-trash"></i>Dejar de seguir
</button>
</form>

<?php else: ?>

<form action="<?php echo e(url('follow/' . $user->id)); ?>" method="POST" style="text-align:left;margin-top:5%">
<?php echo e(csrf_field()); ?>


<button type="submit" id="follow-user-<?php echo e($user->id); ?>" class="btn btn-success">
<i class="fa fa-btn fa-user"></i>Seguir
</button>
</form>

<?php endif; ?>
      </div>
    <div class="row user-data book-button">
    <!-- <button type="submit" name="button" class="col-sm-4 btn btn-success p-1"><a href="/agregarLibros">Seguir</a></button> -->
    

   </div>
  </div>
  </div>
      <div class="container profile">
      <div class="row py-2">
      <div class="">
        <div class="librosInfo row">
          <div class="librosAPrestar col-12 row w-100 mx-auto">
            <h1 class="text-center col-sm-12">Libros para prestar</h1>
            <?php $__empty_1 = true; $__currentLoopData = $userBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($book->state_id == 1): ?>
                <div class="card col-md-3 mx-auto text-center" style="width: 18rem;">
                <img class="card-img-top mx-auto mt-1" src="/storage/<?php echo e($book->image); ?>" alt="Imagen del libro">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($book->title->name); ?></h5>
                  <a href="/bookPost/<?php echo e($book->id); ?>" class="btn btn-success">Ver detalle</a>
                </div>
              </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Por el momento no hay libros cargados</p>
              <?php endif; ?>
          </div>
          <div class="librosLeyendo col-12 row w-100 mx-auto">
            <h1 class="text-center col-sm-12">Son de mi interés</h1>
            <?php $__empty_1 = true; $__currentLoopData = $userBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($book->state_id == 2): ?>
                <div class="card col-md-3 mx-auto text-center" style="width: 18rem;">
                <img class="card-img-top mx-auto mt-1" src="/storage/<?php echo e($book->image); ?>" alt="Imagen del libro">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($book->title->name); ?></h5>
                  <a href="/bookPost/<?php echo e($book->id); ?>" class="btn btn-success">Ver detalle</a>
                </div>
              </div>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Por el momento no hay libros cargados</p>
              <?php endif; ?>
          </div>
          <div class="librosPrestados col-12 row w-100 mx-auto">
            <h1 class="text-center col-sm-12">Libros prestados</h1>
            <?php $__empty_1 = true; $__currentLoopData = $userBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($book->state_id == 3): ?>
                <div class="card col-md-3 mx-auto text-center" style="width: 18rem;">
                <img class="card-img-top mx-auto mt-1" src="/storage/<?php echo e($book->image); ?>" alt="Imagen del libro">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($book->title->name); ?></h5>
                  <a href="/bookPost/<?php echo e($book->id); ?>" class="btn btn-success">Ver detalle</a>
                </div>
              </div>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Por el momento no hay libros cargados</p>
              <?php endif; ?>
          </div>
        </div>
      </div>
    </div>




        </div>

  </div>

  </div>
  </div>
</div>
</div>
<footer class="col-lg-12 footer-home">
  <ul class="navbar-nav mr-auto">
    <li class="nav-item active">
      <a class="nav-link" href="#">Home<span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Nosotros</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">FAQ</a>
    </li>
  </ul>
</footer>

<script src="/js/follow.js">

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>