<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Noti_follow extends Model
{
    //
}
